export interface Filtro {
    body : any
    jql : string
}